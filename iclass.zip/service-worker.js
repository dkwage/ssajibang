/*global chrome*/
chrome.runtime.onMessage.addListener((request) => {
  if (request.message === "options") {
    chrome.tabs.create({
      url: chrome.runtime.getURL("./options/options.html"),
    });
  }
});
