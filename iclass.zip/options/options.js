/*global chrome*/

const iplayOptions = { activate: true, showName: true, showAlarm: true };

window.onload = () => {
  // 옵션 로드
  chrome.storage.local.get(["iplayOptions"], function (result) {
    if (result.iplayOptions !== undefined) {
      for (const option of Object.keys(result.iplayOptions)) {
        iplayOptions[option] = result.iplayOptions[option];
      }
    }
    
    for (const option of Object.keys(iplayOptions)) {
      document.getElementById(option).onclick = onClick;
      document.getElementById(option).checked = iplayOptions[option];
    }
  });
  
  // 기부 모달 기능
  const modal = document.getElementById("donationModal");
  const btn = document.getElementById("donateBtn");
  const span = document.getElementsByClassName("close")[0];
  
  btn.onclick = function() {
    modal.style.display = "block";
  }
  
  span.onclick = function() {
    modal.style.display = "none";
  }
  
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
};

const onClick = (e) => {
  iplayOptions[e.target.id] = e.target.checked;
  chrome.storage.local.set({ iplayOptions: iplayOptions });
};
