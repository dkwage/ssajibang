/*global chrome*/
window.onload = () => {
  document.getElementById('current-year').textContent = new Date().getFullYear();
  document.getElementById("options").onclick = () => {
    chrome.runtime.sendMessage({ message: "options" });
  };
};
